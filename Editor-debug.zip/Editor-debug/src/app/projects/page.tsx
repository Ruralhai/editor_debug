"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export default function ProjectsPage() {
    const [projects, setProjects] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchProjects();
    }, []);

    const fetchProjects = async () => {
        setLoading(true);

        const {
            data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
            setProjects([]);
            setLoading(false);
            return;
        }

        const { data, error } = await supabase
            .from("projects")
            .select("*")
            .eq("user_id", user.id)
            .order("updated_at", { ascending: false });
            
        if (error) {
            console.error(error);
        } else {
            setProjects(data || []);
        }

        setLoading(false);
    };

    const handleDeleteProject = async (id: string) => {
        const confirmDelete = window.confirm(
            "Are you sure you want to delete this project?"
        );

        if (!confirmDelete) return;

        const { error } = await supabase
            .from("projects")
            .delete()
            .eq("id", id);

        if (error) {
            console.error(error);
            alert("❌ Failed to delete project.");
        } else {
            alert("✅ Project deleted successfully!");
            fetchProjects(); // Refresh the list
        }
    };

    return (
        <main className="min-h-screen bg-slate-950 text-white p-8">
            <h1 className="text-4xl font-bold">📂 My Projects</h1>

            <p className="mt-3 text-slate-400">
                View and manage all your saved packaging projects.
            </p>

            <div className="mt-8 rounded-xl border border-slate-800 bg-slate-900 p-6">
                {loading ? (
                    <p>Loading projects...</p>
                ) : projects.length === 0 ? (
                    <p>No projects found.</p>
                ) : (
                    <div className="space-y-4">
                        {projects.map((project) => (
                            <div
                                key={project.id}
                                className="rounded-xl border border-slate-700 bg-slate-950 p-6 shadow-lg"
                            >
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-2xl font-semibold">
                                            {project.project_name || "Untitled Project"}
                                        </h2>

                                        <p className="mt-1 text-slate-400">
                                            Product: {project.product_name}
                                        </p>

                                        <p className="text-slate-400">
                                            Brand: {project.brand_name}
                                        </p>
                                    </div>

                                    <span className="rounded-full bg-blue-600 px-3 py-1 text-sm">
                                        {project.status}
                                    </span>
                                </div>

                                <p className="mt-4 text-sm text-slate-500">
                                    Last Updated: {new Date(project.updated_at).toLocaleString()}
                                </p>

                                <div className="mt-6 flex gap-3">
                                    <button
                                        onClick={() => {
                                            window.location.href = `/design?id=${project.id}`;
                                        }}
                                        className="rounded-lg bg-blue-600 px-4 py-2 hover:bg-blue-700">
                                        Open
                                    </button>

                                    <button
                                        onClick={() => handleDeleteProject(project.id)}
                                        className="rounded-lg bg-red-600 px-4 py-2 hover:bg-red-700">
                                        Delete
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </main>
    );
}
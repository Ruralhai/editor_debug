import { NextResponse } from "next/server";
import { ai } from "@/lib/ai/gemini";

export async function GET() {
    try {
        const models = await ai.models.list();

        return NextResponse.json(models);
    } catch (error) {
        console.error(error);

        return NextResponse.json(
            {
                success: false,
                error: "Failed to list models",
            },
            { status: 500 }
        );
    }
}

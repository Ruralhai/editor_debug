"use client";

import { useState, useEffect } from "react";
import { generatePrompt } from "@/lib/generatePrompt";
import { useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import {
    industries,
    categories,
    packagingTypes,
    packagingStyles,
    materials,
    designStyles,
    finishes,
    printingMethods,
    units,
    sustainabilityOptions
} from "@/data/packagingData";


export default function DesignPage() {
    const searchParams = useSearchParams();
    const projectId = searchParams.get("id");
    const [projectName, setProjectName] = useState("");
    const [productName, setProductName] = useState("");
    const [brandName, setBrandName] = useState("");
    const [industry, setIndustry] = useState("");
    const [category, setCategory] = useState("");
    const [description, setDescription] = useState("");
    const [targetAudience, setTargetAudience] = useState("");
    const [packagingType, setPackagingType] = useState("");
    const [packagingStyle, setPackagingStyle] = useState("");
    const [material, setMaterial] = useState("");
    const [dimensions, setDimensions] = useState({ "width": "", "height": "", "depth": "", "unit": "mm" });
    const [primaryColor, setPrimaryColor] = useState("");
    const [secondaryColor, setSecondaryColor] = useState("");
    const [designStyle, setDesignStyle] = useState("");
    const [language, setLanguage] = useState("");
    const [market, setMarket] = useState("");
    const [requiredText, setRequiredText] = useState("");
    const [aiInstructions, setAiInstructions] = useState("");
    const [finish, setFinish] = useState("");
    const [printingMethod, setPrintingMethod] = useState("");
    const [sustainability, setSustainability] = useState<string[]>([]);
    const [logo, setLogo] = useState<File | null>(null);
    const [logoPreview, setLogoPreview] = useState("");
    const [productImage, setProductImage] = useState<File | null>(null);
    const [productImagePreview, setProductImagePreview] = useState("");
    const [referenceDesign, setReferenceDesign] = useState<File | null>(null);
    const [referenceDesignPreview, setReferenceDesignPreview] = useState("");
    const handleSaveProject = async () => {
        const {
            data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
            alert("Please log in first.");
            return;
        }

        let logoUrl = "";

        if (logo) {
            const fileName = `${user.id}/${Date.now()}-${logo.name}`;

            const { error: uploadError } = await supabase.storage
                .from("project-assets")
                .upload(fileName, logo);

            if (uploadError) {
                alert(uploadError.message);
                return;
            }

            const { data } = supabase.storage
                .from("project-assets")
                .getPublicUrl(fileName);

            logoUrl = data.publicUrl;
        }

        let productImageUrl = "";

        if (productImage) {
            const fileName = `${user.id}/${Date.now()}-${productImage.name}`;

            const { error: uploadError } = await supabase.storage
                .from("project-assets")
                .upload(fileName, productImage);

            if (uploadError) {
                alert(uploadError.message);
                return;
            }

            const { data } = supabase.storage
                .from("project-assets")
                .getPublicUrl(fileName);

            productImageUrl = data.publicUrl;
        }

        let referenceDesignUrl = "";

        if (referenceDesign) {
            const fileName = `${user.id}/reference-${Date.now()}-${referenceDesign.name}`;

            const { error: uploadError } = await supabase.storage
                .from("project-assets")
                .upload(fileName, referenceDesign);

            if (uploadError) {
                alert(uploadError.message);
                return;
            }

            const { data } = supabase.storage
                .from("project-assets")
                .getPublicUrl(fileName);

            referenceDesignUrl = data.publicUrl;
        }

        const projectData = {
            user_id: user.id,
            logo_url: logoUrl,
            product_image_url: productImageUrl,
            reference_design_url: referenceDesignUrl,
            project_name: projectName,
            product_name: productName,
            brand_name: brandName,
            industry,
            category,
            description,
            target_audience: targetAudience,
            packaging_type: packagingType,
            packaging_style: packagingStyle,
            material,
            dimensions,
            finish,
            printing_method: printingMethod,
            sustainability,
            primary_color: primaryColor,
            secondary_color: secondaryColor,
            design_style: designStyle,
            language,
            market,
            required_text: requiredText,
            ai_instructions: aiInstructions,
            updated_at: new Date().toISOString(),
        };

        let error;

        if (projectId) {
            // Update existing project
            const result = await supabase
                .from("projects")
                .update(projectData)
                .eq("id", projectId);

            error = result.error;

        } else {
            // Create new project
            const result = await supabase
                .from("projects")
                .insert([projectData]);

            error = result.error;
        }

        if (error) {
            console.log(error);
            alert(error.message);
        } else {
            alert(
                projectId
                    ? "✅ Project updated successfully!"
                    : "✅ Project saved successfully!"
            );
        }
    };

    useEffect(() => {
        if (projectId) {
            fetchProject();
        }
    }, [projectId]);

    const fetchProject = async () => {
        const { data, error } = await supabase
            .from("projects")
            .select("*")
            .eq("id", projectId)
            .single();

        if (error) {
            console.error(error);
            return;
        }

        setProjectName(data.project_name || "");
        setProductName(data.product_name || "");
        setBrandName(data.brand_name || "");
        setIndustry(data.industry || "");
        setCategory(data.category || "");
        setDescription(data.description || "");
        setTargetAudience(data.target_audience || "");
        setPackagingType(data.packaging_type || "");
        setPackagingStyle(data.packaging_style || "");
        setMaterial(data.material || "");
        setDimensions(data.dimensions || {
            width: "",
            height: "",
            depth: "",
            unit: "mm",
        });
        setFinish(data.finish || "");
        setPrintingMethod(data.printing_method || "");
        setSustainability(data.sustainability || []);
        setPrimaryColor(data.primary_color || "");
        setSecondaryColor(data.secondary_color || "");
        setDesignStyle(data.design_style || "");
        setLanguage(data.language || "");
        setMarket(data.market || "");
        setRequiredText(data.required_text || "");
        setAiInstructions(data.ai_instructions || "");
        setLogoPreview(data.logo_url || "");
        setProductImagePreview(data.product_image_url || "");
        setReferenceDesignPreview(data.reference_design_url || "");
    };

    const handleGenerateDesign = async () => {
        const prompt = generatePrompt({
            product_name: productName,
            brand_name: brandName,
            industry,
            category,
            description,
            target_audience: targetAudience,
            packaging_type: packagingType,
            packaging_style: packagingStyle,
            material,
            finish,
            printing_method: printingMethod,
            sustainability,
            primary_color: primaryColor,
            secondary_color: secondaryColor,
            design_style: designStyle,
            language,
            market,
            required_text: requiredText,
            ai_instructions: aiInstructions,
        });

        const response = await fetch("/api/generate-design", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                prompt,
            }),
        });

        const data = await response.json();

        console.log(data);
    };

    return (
        <main className="min-h-screen bg-slate-950 text-white p-8">
            <h1 className="text-4xl font-bold">
                Create New Packaging Design
            </h1>

            <p className="mt-3 text-slate-400">
                Describe your product and let AI generate packaging ideas.
            </p>

            <div className="mt-8 rounded-xl border border-slate-800 bg-slate-900 p-6 space-y-6">

                {/* Product Information */}
                <div>
                    <h2 className="text-xl font-semibold mb-4">📦 Product Information</h2>

                    <input
                        type="text"
                        placeholder="Project Name"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Product Name"
                        value={productName}
                        onChange={(e) => setProductName(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Brand Name"
                        value={brandName}
                        onChange={(e) => setBrandName(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />
                    <select
                        value={industry}
                        onChange={(e) => setIndustry(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    >
                        <option value="">Select Industry</option>
                        {industries.map((industry) => (
                            <option key={industry} value={industry}>
                                {industry}
                            </option>
                        ))}
                    </select>

                    <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        disabled={!industry}
                    >
                        <option value="">Select Category</option>

                        {industry &&
                            categories[industry as keyof typeof categories]?.map((item) => (
                                <option key={item} value={item}>
                                    {item}
                                </option>
                            ))}
                    </select>

                    <textarea
                        placeholder="Product Description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />
                </div>

                {/* Target Market */}
                <div>
                    <h2 className="text-xl font-semibold mb-4">🎯 Target Market</h2>

                    <input
                        type="text"
                        placeholder="Target Audience"
                        value={targetAudience}
                        onChange={(e) => setTargetAudience(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Language"
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />

                    <input
                        type="text"
                        placeholder="Country / Market"
                        value={market}
                        onChange={(e) => setMarket(e.target.value)}
                        className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    />
                </div>
                {/* Packaging Details */}
                <div>
                    <h2 className="text-xl font-semibold mb-4">
                        📦 Packaging Details
                    </h2>

                    <select
                        value={packagingType}
                        onChange={(e) => {
                            setPackagingType(e.target.value);
                            setPackagingStyle("");
                        }}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3">

                        <option value="">Select Packaging Type</option>
                        {packagingTypes.map((type) => (
                            <option key={type} value={type}>
                                {type}
                            </option>
                        ))}
                    </select>

                    <select
                        value={packagingStyle}
                        onChange={(e) => setPackagingStyle(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        disabled={!packagingType}
                    >
                        <option value="">Select Packaging Style</option>

                        {packagingType &&
                            packagingStyles[
                                packagingType as keyof typeof packagingStyles
                            ]?.map((style) => (
                                <option key={style} value={style}>
                                    {style}
                                </option>
                            ))}
                    </select>

                    <select
                        value={material}
                        onChange={(e) => setMaterial(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    >
                        <option value="">Select Material</option>
                        {materials.map((material) => (
                            <option key={material} value={material}>
                                {material}
                            </option>
                        ))}
                    </select>

                    {/* Dimensions */}

                    <h3 className="mb-3 mt-4 text-lg font-semibold">
                        📏 Dimensions
                    </h3>

                    <div className="grid grid-cols-2 gap-4">

                        <input
                            type="number"
                            placeholder="Width"
                            value={dimensions.width}
                            onChange={(e) =>
                                setDimensions({
                                    ...dimensions,
                                    width: e.target.value,
                                })
                            }
                            className="rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        />

                        <input
                            type="number"
                            placeholder="Height"
                            value={dimensions.height}
                            onChange={(e) =>
                                setDimensions({
                                    ...dimensions,
                                    height: e.target.value,
                                })
                            }
                            className="rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        />

                        <input
                            type="number"
                            placeholder="Depth"
                            value={dimensions.depth}
                            onChange={(e) =>
                                setDimensions({
                                    ...dimensions,
                                    depth: e.target.value,
                                })
                            }
                            className="rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        />

                        <select
                            value={dimensions.unit}
                            onChange={(e) =>
                                setDimensions({
                                    ...dimensions,
                                    unit: e.target.value,
                                })
                            }
                            className="rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        >
                            {units.map((unit) => (
                                <option key={unit} value={unit}>
                                    {unit}
                                </option>
                            ))}
                        </select>

                    </div>

                    <select
                        value={finish}
                        onChange={(e) => setFinish(e.target.value)}
                        className="mt-4 w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    >
                        <option value="">Select Finish</option>

                        {finishes.map((finish) => (
                            <option key={finish} value={finish}>
                                {finish}
                            </option>
                        ))}
                    </select>

                </div>

                {/* Printing Method */}
                <select
                    value={printingMethod}
                    onChange={(e) => setPrintingMethod(e.target.value)}
                    className="mt-4 w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                >
                    <option value="">Select Printing Method</option>

                    {printingMethods.map((method) => (
                        <option key={method} value={method}>
                            {method}
                        </option>
                    ))}
                </select>

                {/* Sustainability */}

                <div className="mt-6">
                    <h3 className="mb-3 text-lg font-semibold">
                        🌱 Sustainability
                    </h3>

                    <div className="grid grid-cols-2 gap-3">
                        {sustainabilityOptions.map((option) => (
                            <label
                                key={option}
                                className="flex items-center gap-2 rounded-lg border border-slate-700 p-3"
                            >
                                <input
                                    type="checkbox"
                                    checked={sustainability.includes(option)}
                                    onChange={(e) => {
                                        if (e.target.checked) {
                                            setSustainability([...sustainability, option]);
                                        } else {
                                            setSustainability(
                                                sustainability.filter((item) => item !== option)
                                            );
                                        }
                                    }}
                                />

                                <span>{option}</span>
                            </label>
                        ))}
                    </div>
                </div>

                {/* Brand Assets */}

                <div className="mt-8">
                    <h2 className="mb-4 text-xl font-semibold">
                        📎 Brand Assets
                    </h2>

                    {/* Logo */}

                    <div className="mb-6">
                        <label className="mb-2 block font-medium">
                            Upload Logo
                        </label>

                        <input
                            type="file"
                            accept="image/*,.svg"
                            onChange={(e) => {
                                const file = e.target.files?.[0];

                                if (file) {
                                    setLogo(file);
                                    setLogoPreview(URL.createObjectURL(file));
                                }
                            }}
                            className="w-full rounded-lg border border-slate-700 bg-slate-950 p-3"
                        />

                        {logoPreview && (
                            <div className="mt-4">
                                <img
                                    src={logoPreview}
                                    alt="Logo Preview"
                                    className="h-28 w-28 rounded-lg border border-slate-700 object-contain bg-white p-2"
                                />
                            </div>
                        )}

                    </div>

                    {/* Product Image */}

                    <div className="mb-6">
                        <label className="mb-2 block font-medium">
                            Upload Product Image
                        </label>

                        <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                                const file = e.target.files?.[0];

                                if (file) {
                                    setProductImage(file);
                                    setProductImagePreview(URL.createObjectURL(file));
                                }
                            }}
                            className="w-full rounded-lg border border-slate-700 bg-slate-950 p-3"
                        />

                        {productImagePreview && (
                            <div className="mt-4">
                                <img
                                    src={productImagePreview}
                                    alt="Product Image Preview"
                                    className="h-28 w-28 rounded-lg border border-slate-700 object-contain bg-white p-2"
                                />
                            </div>
                        )}
                    </div>

                    {/* Reference Design */}

                    <div>
                        <label className="mb-2 block font-medium">
                            Upload Reference Design (Optional)
                        </label>

                        <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                                const file = e.target.files?.[0];

                                if (file) {
                                    setReferenceDesign(file);
                                    setReferenceDesignPreview(URL.createObjectURL(file));
                                }
                            }}
                            className="w-full rounded-lg border border-slate-700 bg-slate-950 p-3"
                        />

                        {referenceDesignPreview && (
                            <div className="mt-4">
                                <img
                                    src={referenceDesignPreview}
                                    alt="Reference Design Preview"
                                    className="h-28 w-28 rounded-lg border border-slate-700 object-contain bg-white p-2"
                                />
                            </div>
                        )}

                    </div>
                </div>

                {/* Design Preferences */}
                <div>
                    <h2 className="text-xl font-semibold mb-4">
                        🎨 Design Preferences
                    </h2>

                    <div className="mb-4">
                        <label className="mb-2 block text-sm font-medium">
                            Primary Color
                        </label>

                        <input
                            type="color"
                            value={primaryColor}
                            onChange={(e) => setPrimaryColor(e.target.value)}
                            className="h-12 w-full rounded-lg border border-slate-700 bg-slate-950"
                        />
                    </div>

                    <div className="mb-4">
                        <label className="mb-2 block text-sm font-medium">
                            Secondary Color
                        </label>

                        <input
                            type="color"
                            value={secondaryColor}
                            onChange={(e) => setSecondaryColor(e.target.value)}
                            className="h-12 w-full rounded-lg border border-slate-700 bg-slate-950"
                        />
                    </div>

                    <select
                        value={designStyle}
                        onChange={(e) => setDesignStyle(e.target.value)}
                        className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                    >
                        <option value="">Select Design Style</option>
                        {designStyles.map((style) => (
                            <option key={style} value={style}>
                                {style}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Content & AI Instructions */}

                <div>
                    <h2 className="text-xl font-semibold mb-4">
                        📝 Content & AI Instructions
                    </h2>

                    <textarea
                        placeholder="Required Text (Ingredients, Tagline, Warnings, etc.)"
                        value={requiredText}
                        onChange={(e) => setRequiredText(e.target.value)}
                        className="w-full mb-4 rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        rows={4}
                    />

                    <textarea
                        placeholder="Additional AI Instructions"
                        value={aiInstructions}
                        onChange={(e) => setAiInstructions(e.target.value)}
                        className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                        rows={5}
                    />
                </div>

                {/* Project Completion */}

                {(() => {
                    const checks = [
                        projectName,
                        productName,
                        brandName,
                        industry,
                        category,
                        packagingType,
                        packagingStyle,
                        material,
                        dimensions.width,
                        dimensions.height,
                        finish,
                        printingMethod,
                        designStyle,
                        logo,
                        productImage,
                    ];

                    const completed = checks.filter(Boolean).length;
                    const total = checks.length;
                    const percentage = Math.round((completed / total) * 100);

                    return (
                        <div className="mt-8 rounded-xl border border-slate-700 bg-slate-950 p-6">
                            <div className="flex items-center justify-between">
                                <h2 className="text-xl font-bold">📊 Project Completion</h2>
                                <span className="text-blue-400 font-semibold">
                                    {percentage}%
                                </span>
                            </div>

                            <div className="mt-4 h-3 w-full rounded-full bg-slate-800">
                                <div
                                    className="h-3 rounded-full bg-blue-500 transition-all duration-500"
                                    style={{ width: `${percentage}%` }}
                                />
                            </div>

                            <div className="mt-6 space-y-2">
                                <p>{productName ? "✅" : "⚠️"} Product Information</p>
                                <p>{packagingType ? "✅" : "⚠️"} Packaging Specifications</p>
                                <p>{designStyle ? "✅" : "⚠️"} Design Preferences</p>
                                <p>{logo ? "✅" : "⚠️"} Logo Uploaded</p>
                                <p>{productImage ? "✅" : "⚠️"} Product Image Uploaded</p>
                                <p>{requiredText ? "✅" : "⚠️"} Required Content</p>
                            </div>
                        </div>
                    );
                })()}

                {/* Project Summary */}

                <div className="mt-8 rounded-xl border border-slate-700 bg-slate-950 p-6">
                    <h2 className="mb-4 text-2xl font-bold">
                        📋 Project Summary
                    </h2>

                    <div className="space-y-3">

                        <p>
                            <strong>Project:</strong> {projectName || "Untitled Project"}
                        </p>

                        <p>
                            <strong>Product:</strong> {productName || "Not provided"}
                        </p>

                        <p>
                            <strong>Brand:</strong> {brandName || "Not provided"}
                        </p>

                        <p>
                            <strong>Industry:</strong> {industry || "Not selected"}
                        </p>

                        <p>
                            <strong>Category:</strong> {category || "Not selected"}
                        </p>

                        <p>
                            <strong>Packaging:</strong>{" "}
                            {packagingType
                                ? `${packagingType} (${packagingStyle || "Style not selected"})`
                                : "Not selected"}
                        </p>

                        <p>
                            <strong>Material:</strong> {material || "Not selected"}
                        </p>

                        <p>
                            <strong>Dimensions:</strong>{" "}
                            {dimensions.width || "-"} × {dimensions.height || "-"} ×{" "}
                            {dimensions.depth || "-"} {dimensions.unit}
                        </p>

                        <p>
                            <strong>Finish:</strong> {finish || "Not selected"}
                        </p>

                        <p>
                            <strong>Printing:</strong> {printingMethod || "Not selected"}
                        </p>

                        <p>
                            <strong>Target Market:</strong> {market || "Not provided"}
                        </p>

                        <p>
                            <strong>Design Style:</strong> {designStyle || "Not selected"}
                        </p>

                        <p>
                            <strong>Sustainability:</strong>{" "}
                            {sustainability.length > 0
                                ? sustainability.join(", ")
                                : "None selected"}
                        </p>

                    </div>
                </div>

                <button
                    type="button"
                    onClick={handleSaveProject}
                    className="w-full rounded-lg border border-slate-600 bg-slate-800 px-6 py-4 text-lg font-semibold hover:bg-slate-700 transition"
                >
                    💾 Save Project
                </button>

                {/* Generate Button */}

                <button
                    type="button"
                    onClick={handleGenerateDesign}
                    className="w-full rounded-lg bg-blue-600 px-6 py-4 text-lg font-semibold hover:bg-blue-700"
                >
                    🚀 Generate AI Packaging Design
                </button>

            </div>

        </main>
    );
}
